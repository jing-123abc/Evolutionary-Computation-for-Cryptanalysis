# Evolutionary Computation for Cryptanalysis

## Getting Started

The code is split into multiple .Rmd files:

```
ga.Rmd, pso.Rmd, helper.Rmd, rs.Rmd, sdes.Rmd, bf.Rmd, main.Rmd
```

To perform the cryptanalysis, first launch R Studio. 

If R Studio is not installed, download it at https://www.rstudio.com/.

* Afterwards, run the ```helper.Rmd``` file followed by ```ga.Rmd```, ```pso.Rmd```, ```bf.Rmd```, ```rs.Rmd```, ```sdes.Rmd```. 

* Finally, run the ```main.Rmd```.

